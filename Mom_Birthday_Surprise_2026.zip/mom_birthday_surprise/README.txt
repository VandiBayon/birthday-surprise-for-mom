MOM'S BIRTHDAY SURPRISE
========================

This folder contains the first version of the birthday webpage.

Files:
- index.html
- assets/mom-photo-1.jpeg
- assets/mom-photo-2.jpeg
- assets/mom-photo-3.jpeg

The page already has placeholders for:
- 2 additional photos
- 1 birthday video

NEXT STEP:
Upload the whole folder to a free static website host. Once you have the public website link, a QR code can be generated that opens the birthday page directly.

IMPORTANT:
Keep the assets folder together with index.html when uploading.
